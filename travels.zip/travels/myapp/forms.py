from django import forms

dest = (("1","Vilupuram,Chetpet,Chennai"),
("2","Ariyalur,Thambaram,Chennai"),
("3","Karur,Erode,Coimbatore"),
("4","Madurai,Kanyakumari,thiruvandram")
)

class Tickets(forms.Form):
    Bus_no = forms.IntegerField()
    Destination = forms.ChoiceField(choices=dest)
    No = forms.IntegerField()