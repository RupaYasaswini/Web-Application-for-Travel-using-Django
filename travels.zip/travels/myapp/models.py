from django.db import models

# Create your models here.

dest = (("1","Vilupuram,Chetpet,Chennai"),
("2","Ariyalur,Thambaram,Chennai"),
("3","Karur,Erode,Coimbatore"),
("4","Madurai,Kanyakumari,thiruvandram")
)

class Bus(models.Model):
    Bus_no = models.IntegerField()
    Depature = models.TimeField()
    Destination = models.CharField(max_length=100,choices=dest)
    Seats = models.IntegerField()
    Cost = models.IntegerField()

    def __str__(self):
        return self.Destination