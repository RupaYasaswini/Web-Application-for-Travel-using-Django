from django.shortcuts import render
from django.http import HttpResponse
from .models import Bus
from .forms import Tickets
import datetime
# Create your views here.

def base(request):
    if request.method == 'POST':
        form = Tickets(request.POST)
        if form.is_valid():
            Bus_no = form.cleaned_data['Bus_no']
            Destination = form.cleaned_data['Destination']
            No = form.cleaned_data['No']
            b = Bus.objects.get(pk=Destination)
            available = b.Seats
            Depature = datetime.time(10,30,00)
            if available>=No:
                Cost = No*1200
                b.Seats = available-No
                b.save()
                
                return HttpResponse(f'Amount: {Cost}')
            else:
                return HttpResponse("Booking failed")
    
    else:
        form = Tickets()
    
    return render(request,"bus.html",{'form':form})